<footer>

<div class="about" id="about">
  <img src="<?php echo get_template_directory_uri(); ?>/img/unnamed.jpg" alt="me" class="me">
  <h2 class="profile">市原樂</h2>
  <p class="myne">大学在学中に個人で収入を稼げる力をつけたいと思い、プログラミング独学を始める。浪人生活を経て一橋大学に合格した経験をもとに、子育てや勉強法に関する情報を並行して発信中。</p>
</div>
    <div class="container">
      <div class="row">
        <a href="<?php echo esc_url(home_url('/')); ?>"></a>
        <div class="col-lg-8 col-md-10 mx-auto">
          <ul class="list-inline text-center">
            <li class="list-inline-item">
              <a href="#">
                <span class="fa-stack fa-lg">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-twitter fa-stack-1x fa-inverse"></i>
                </span>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <span class="fa-stack fa-lg">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-facebook-f fa-stack-1x fa-inverse"></i>
                </span>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <span class="fa-stack fa-lg">
                  <i class="fas fa-circle fa-stack-2x"></i>
                  <i class="fab fa-github fa-stack-1x fa-inverse"></i>
                </span>
              </a>
            </li>
          </ul>
          <p class="copyright text-muted">Copyright <?php echo date('Y'); ?>  <?php bloginfo('name') ?> All Right Reserved</p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo get_template_directory_uri(); ?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="<?php echo get_template_directory_uri(); ?>/js/clean-blog.min.js"></script>
<?php wp_footer(); ?>
</body>

</html>